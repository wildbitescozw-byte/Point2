# Glass Launcher 🍷

A custom Android TV home launcher: a rotating wine-glass app carousel with a "krr-click" sound, a floating frosted tab, a wall + cladding glass look, a big clock with an animated day/evening/night icon, and a built-in music player that reads music from a plugged-in drive.

Designed for a 122.5 x 71 cm screen where the plain wall ends at 96 cm and the cladding starts after it.

## Get the APK (no Android Studio needed)
1. Create a new GitHub repo and push this folder to it.
2. Open the **Actions** tab, open the latest **Build APK** run, and download `GlassLauncher-debug-apk`.
3. Unzip it to get `app-debug.apk`.

## Install on the TV box
```
adb connect <tv-box-ip>:5555
adb install -r app-debug.apk
adb shell cmd package set-home-activity com.glasslauncher.tv/.MainActivity
```
If the last command is refused, press Home on the remote and choose Glass Launcher with "Always".
Allow the audio permission when asked.

## Remote control
- Left / Right: rotate the glass
- OK: open the selected app
- Up: next track, Down: play/pause (media keys also work)

## Customize
- `app/src/main/assets/index.html` is the whole UI (colors, wall/cladding split, sizes). Open it in a desktop browser to preview.
- `PINNED` at the top of `MainActivity.kt` sets which apps come first. The ring shows 8 apps.
- Music comes from Android's media index, so the USB drive must be mounted and scanned by the box (Rescan button in the player).
