package com.glasslauncher.tv

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import kotlin.random.Random

/** Apps shown first (in this order). Edit freely. The ring holds 8 apps. */
val PINNED = listOf(
    "com.google.android.youtube.tv", "com.netflix.ninja", "com.amazon.amazonvideo.livingroom",
    "com.spotify.tv.android", "com.disney.disneyplus", "com.android.chrome", "com.android.tv.settings"
)

data class Track(val uri: Uri, val title: String, val artist: String)

class Music {
    var tracks: List<Track> = emptyList()
    private var mp: MediaPlayer? = null
    private var ready = false
    var idx = -1
    var shuffle = false
    var repeat = false

    fun scan(ctx: Context) {
        val base = if (Build.VERSION.SDK_INT >= 29) MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val out = ArrayList<Track>()
        try {
            ctx.contentResolver.query(
                base,
                arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST),
                "${MediaStore.Audio.Media.IS_MUSIC}!=0 OR ${MediaStore.Audio.Media.DURATION}>60000",
                null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE"
            )?.use { c ->
                while (c.moveToNext()) out.add(Track(ContentUris.withAppendedId(base, c.getLong(0)), c.getString(1) ?: "Unknown", c.getString(2) ?: ""))
            }
        } catch (e: Exception) { }
        tracks = out
    }

    fun play(ctx: Context, i: Int) {
        if (tracks.isEmpty()) return
        idx = ((i % tracks.size) + tracks.size) % tracks.size
        release()
        val p = MediaPlayer(); mp = p
        p.setAudioAttributes(AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).setUsage(AudioAttributes.USAGE_MEDIA).build())
        try {
            p.setDataSource(ctx, tracks[idx].uri)
            p.setOnPreparedListener { ready = true; it.start() }
            p.setOnCompletionListener { if (repeat) play(ctx, idx) else next(ctx) }
            p.setOnErrorListener { _, _, _ -> ready = false; true }
            p.prepareAsync()
        } catch (e: Exception) { ready = false }
    }

    fun next(ctx: Context) = play(ctx, if (shuffle && tracks.size > 1) Random.nextInt(tracks.size) else idx + 1)
    fun prev(ctx: Context) = play(ctx, idx - 1)

    fun toggle(ctx: Context) {
        val p = mp
        if (p == null) { play(ctx, 0); return }
        if (!ready) return
        if (p.isPlaying) p.pause() else p.start()
    }

    fun seek(f: Double) { val p = mp; if (p != null && ready) p.seekTo((f * p.duration).toInt()) }

    fun state(): String {
        val o = JSONObject().put("idx", idx)
        try {
            val p = mp
            if (p != null && ready) o.put("playing", p.isPlaying).put("pos", p.currentPosition).put("dur", p.duration)
            else o.put("playing", false).put("pos", 0).put("dur", 0)
        } catch (e: Exception) { o.put("playing", false).put("pos", 0).put("dur", 0) }
        return o.toString()
    }

    fun release() { ready = false; try { mp?.release() } catch (e: Exception) { }; mp = null }
}

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val music = Music()
    private val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
        web.requestFocus()
        if (checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(perm), 1)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        js("window.onTracks&&onTracks()")
    }

    override fun onResume() { super.onResume(); js("window.onTracks&&onTracks()") }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
    }

    @Deprecated("Home screen: Back does nothing")
    override fun onBackPressed() { }

    private fun js(code: String) { if (::web.isInitialized) web.post { web.evaluateJavascript(code, null) } }

    private fun iconUri(d: Drawable): String {
        val bmp = Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, 128, 128); d.draw(Canvas(bmp))
        val bo = ByteArrayOutputStream(); bmp.compress(Bitmap.CompressFormat.PNG, 100, bo)
        return "data:image/png;base64," + Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
    }

    inner class Bridge {
        @JavascriptInterface fun getApps(): String {
            val pm = packageManager
            val seen = HashSet<String>()
            val list = ArrayList<ResolveInfo>()
            for (cat in arrayOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER))
                for (ri in pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0))
                    if (ri.activityInfo.packageName != packageName && seen.add(ri.activityInfo.packageName)) list.add(ri)
            list.sortWith(compareBy({ val i = PINNED.indexOf(it.activityInfo.packageName); if (i < 0) 999 else i }, { it.loadLabel(pm).toString().lowercase() }))
            val arr = JSONArray()
            for (ri in list.take(8)) arr.put(JSONObject().put("name", ri.loadLabel(pm).toString()).put("pkg", ri.activityInfo.packageName).put("icon", iconUri(ri.loadIcon(pm))))
            return arr.toString()
        }

        @JavascriptInterface fun launch(pkg: String) = runOnUiThread {
            val i = packageManager.getLeanbackLaunchIntentForPackage(pkg) ?: packageManager.getLaunchIntentForPackage(pkg)
            i?.let { it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(it) }
        }

        @JavascriptInterface fun tracks(): String {
            music.scan(this@MainActivity)
            val arr = JSONArray()
            music.tracks.forEach { arr.put(JSONObject().put("title", it.title).put("artist", it.artist)) }
            return arr.toString()
        }

        @JavascriptInterface fun play(i: Int) = runOnUiThread { music.play(this@MainActivity, i) }
        @JavascriptInterface fun toggle() = runOnUiThread { music.toggle(this@MainActivity) }
        @JavascriptInterface fun next() = runOnUiThread { music.next(this@MainActivity) }
        @JavascriptInterface fun prev() = runOnUiThread { music.prev(this@MainActivity) }
        @JavascriptInterface fun setShuffle(b: Boolean) { music.shuffle = b }
        @JavascriptInterface fun setRepeat(b: Boolean) { music.repeat = b }
        @JavascriptInterface fun seek(f: Double) = runOnUiThread { music.seek(f) }
        @JavascriptInterface fun state(): String = music.state()
    }

    override fun onDestroy() { music.release(); super.onDestroy() }
}
